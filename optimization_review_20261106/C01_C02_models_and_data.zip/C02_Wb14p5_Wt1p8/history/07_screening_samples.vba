With FDSolver
.SetMethod "", "Discrete samples only"
.ResetSampleIntervals "all"
.AddSampleInterval "5", "5", "1", "Single", "False"
.AddSampleInterval "10", "10", "1", "Single", "False"
.AddSampleInterval "20", "20", "1", "Single", "False"
.AddSampleInterval "30", "30", "1", "Single", "False"
.AddSampleInterval "35", "35", "1", "Single", "False"
.AddSampleInterval "40", "40", "1", "Single", "True"
.AddSampleInterval "45", "45", "1", "Single", "False"
.AddSampleInterval "50", "50", "1", "Single", "False"
.AddSampleInterval "55", "55", "1", "Single", "False"
End With