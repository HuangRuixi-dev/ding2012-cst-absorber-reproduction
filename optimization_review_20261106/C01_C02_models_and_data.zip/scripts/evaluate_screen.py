from pathlib import Path
import json,re,csv,sys,math
D=Path(sys.argv[1]); cfg=json.loads((D/'parameters.json').read_text()); raw=json.loads((D/'sparameters.json').read_text()); cutoff=json.loads((D/'port_cutoffs.json').read_text()); f=next(iter(raw.values()))['frequency_GHz']; rows=[]
for j,x in enumerate(f):
 R=T=0.;s11=None
 for key,v in raw.items():
  tok=re.findall(r'Z(?:max|min)\((\d+)\)',key)
  if not tok or tok[-1]!='1':continue
  n=int(tok[0]); port='Zmax' if 'SZmax' in key else 'Zmin'; fc=cfg['modes'][n-1]['cutoff_GHz']
  if abs(cutoff.get(port+'(%d)'%n,fc)-fc)>1e-6:raise ValueError('Mode mapping mismatch')
  power=v['real'][j]**2+v['imag'][j]**2
  if port=='Zmax' and n==1:s11=10*math.log10(max(power,1e-300))
  if x<=fc+1e-8:continue
  if port=='Zmax':R+=power
  else:T+=power
 rows.append([x,1-R-T,R,T,s11])
rows.sort()
with (D/'spectrum.csv').open('w',newline='') as h:
 w=csv.writer(h);w.writerow(['frequency_GHz','A','R','T','S11_dB']);w.writerows(rows)
inside=[r for r in rows if 5<=r[0]<=40]; outside=[r for r in rows if r[0]>=45]
m={'case':D.name,'screening_only':True,'sample_count':len(rows),'min_sampled_A_5_40':min(r[1] for r in inside),'mean_sampled_A_45_55':sum(r[1] for r in outside)/len(outside),'no_continuous_band_claim':True,'samples':rows}
(D/'screening_metrics.json').write_text(json.dumps(m,indent=2));print(json.dumps(m,indent=2))
